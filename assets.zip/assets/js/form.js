document.addEventListener('body', function() {
    var form = document.querySelector('form');
  
    form.addEventListener('submit', function(event) {
      var inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
      var isValid = true;
  
      for (var i = 0; i < inputs.length; i++) {
        if (!inputs[i].value) {
          isValid = false;
          inputs[i].classList.add('error');
        } else {
          inputs[i].classList.remove('error');
        }
      }
  
      if (!isValid) {
        event.preventDefault();
        alert('Mohon lengkapi semua field sebelum mengirimkan formulir.');
      }
    });
  });
  