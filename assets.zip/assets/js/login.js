// Ambil referensi elemen-elemen yang diperlukan
const form = document.getElementById('loginForm');
const usernameInput = document.querySelector('input[name="username"]');
const passwordInput = document.querySelector('input[name="password"]');

// Tambahkan event listener pada saat form disubmit
form.addEventListener('submit', function(event) {
  event.preventDefault(); // Menghentikan aksi default form submit

  // Ambil nilai username dan password yang diinputkan
  const username = usernameInput.value;
  const password = passwordInput.value;

  // Lakukan validasi sederhana
  if (username === 'admin' && password === '123') {
    // Jika username dan password benar, redirect ke halaman das.html
    window.location.href = 'dashboard.html';
  } else {
    // Jika username atau password salah, tampilkan pesan error
    const errorText = document.createElement('p');
    errorText.textContent = 'Invalid username or password. Please try again.';
    errorText.style.color = 'red';
    form.appendChild(errorText);
  }
});